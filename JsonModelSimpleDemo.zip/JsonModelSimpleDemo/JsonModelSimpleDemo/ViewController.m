//
//  ViewController.m
//  JsonModelSimpleDemo
//
//  Created by GadgetZone on 30/09/16.
//  Copyright © 2016 GadgetZone. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self ApiCall];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)ApiCall
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDAnimationFade;
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    
    if (networkStatus == NotReachable)
    {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please check your internet connection" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        [JSONHTTPClient postJSONFromURLWithString:[NSString stringWithFormat:[BASEURL stringByAppendingString:@"service=login"]]params:@{@"password":@"5923"} completion:^(id json, JSONModelError *err)
         {
             [MBProgressHUD hideHUDForView:self.view animated:YES];
             
             if (err)
             {
                 NSLog(@"%@",err.description);
                 UIAlertView *toast = [[UIAlertView alloc] initWithTitle:@"Alert" message:[NSString stringWithFormat:@"%@",err.description] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                 [toast show];
             }
             else
             {
                 responseData = (NSMutableDictionary *)json;
                 
                 NSLog(@"%@",responseData);
                 
                 if ([[responseData valueForKey:@"result"] isEqualToString: @"success"])
                 {
                     NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                     
                     [defaults setObject:[[responseData objectForKey:@"data"]valueForKey:@"vanue"] forKey:@"strVanue"];
                     
                     [defaults synchronize];
                     
                     NSLog(@"strVanue : %@",[defaults valueForKey:@"strVanue"]);
                    
                 }
                 else
                 {
                     UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:[responseData valueForKey:@"data"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                     [alert show];
                 }
             }
         }];
    }
}

@end
