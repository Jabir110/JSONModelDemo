//
//  ViewController.h
//  JsonModelSimpleDemo
//
//  Created by GadgetZone on 30/09/16.
//  Copyright © 2016 GadgetZone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "Reachability.h"
#import "JSONHTTPClient.h"
#import "UIImageView+WebCache.h"

@interface ViewController : UIViewController
{
    NSMutableDictionary *responseData;
}

@end

